
package extrems;

import java.util.Random;
import java.util.Scanner;


public class Extrems {

  
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter seed : ");
        int seed = sc.nextInt();
        System.out.println("Enter number of values : ");
        int number = sc.nextInt();
        System.out.println("Enter smallest number : ");
        int start = sc.nextInt();
        System.out.println("Enter largest number : ");
        int end = sc.nextInt();
        Random r = new Random(seed);
        int[] array = new int[number];
        for(int i=0; i<number; i++) // assigning random number to list 
        {
            array[i]= r.nextInt((end-start)+1)+start;
        }  
        Print(array,number);
        System.out.println("Smallest number : " + start);
        System.out.println("Largest number : " + end);
    }
    public static void Print(int[] array,int number)
    {
        for(int i=0; i<number; i++) // assigning random number to list 
        {
            System.out.print(array[i]+ " "); 
        }
    }   
    
    
}
