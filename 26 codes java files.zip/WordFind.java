
package wordfind;

import java.io.*;
import java.util.Scanner;


public class WordFind {

    public static void main(String[] args) throws IOException {
       
        
        
            Scanner f = new Scanner(new File("find.txt"));
            String str;
            String[] array = new String[10];
            for(int i=0; i<10; i++)
            {
                array[i]=f.nextLine();
                array[i]=array[i].toUpperCase();
            }
            for ( String j : array)
            {
                System.out.println(j);
            }
            while (f.hasNext())
            {
                str=f.nextLine();
                System.out.print(str + " "); 
            }
            
  
    }
    
}
