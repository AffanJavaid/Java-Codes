
package average;
import java.util.Scanner;
import java.io.*;
public class Average {

   
    public static void main(String[] args) throws IOException
    {
        Scanner sc = new Scanner(new File (� Average.txt�));
        System.out.println("Enter number of values : ");
        int n = sc.nextInt();
        int[] array = new int[n];
        for(int i=0; i<n; i++) // assigning random number to list 
        {
            System.out.println("Write value : ");
            array[i]= sc.nextInt();
        }  
        Print(array,n);
    }
    public static void Print(int[] array, int n)
    {
        int sum=0;
        float average;
        System.out.println("The array is  " );
        System.out.print("[ " );
        for(int i=0; i<n; i++) // assigning random number to list 
        {
            System.out.print( array[i] + "  ");
            sum = sum + array[i];
        }
        average=sum/n;
        System.out.println("] Average is  " + average);
    }
}
    
