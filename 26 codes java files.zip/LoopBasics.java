
package loopbasics;

import java.util.Scanner;
import java.util.Random;
public class LoopBasics {
    
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    M0();
    System.out.println("Enter number for factorial : ");
    int n = sc.nextInt();
    int fact = M1(n);
    System.out.println("Factorial : " + fact);
    M2();
    M3();
    M4();
    M5();
    M6();
    M7();
    M8();
    }
    public static void M0()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter starting of loop : ");
        int start = sc.nextInt();
        System.out.println("Enter ending of loop : ");
        int end = sc.nextInt();
        System.out.println("Enter incremental value of loop : ");
        int inc = sc.nextInt();
        if (start<end)
        {
            System.out.println("increasing loop ");
            for (int i=start; i<=end; i=i+inc)
            {          
                System.out.print(i+ " ");   
            }
        }
        else
        {
            System.out.println("decreasing loop ");
            for (int i=start; i>=end; i=i-inc)
            {
                
                System.out.print(i+ " ");
            }
        }
    }
    public static int M1(int n)
    {
        if ( n==0 )
            return 1;
        else 
            return ( n * M1(n-1));
    }
    public static void M2()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter String : ");
        String name = sc.nextLine();
        System.out.println("Ente number of times want to repeat  : ");
        int n = sc.nextInt();

            for (int i=0; i<=n; i++)
            {
                System.out.print(name + " ");   
            }
        
    }
    public static void M3()
    {
        System.out.println("Enter string to reverse:");
        Scanner read = new Scanner(System.in);
        String str = read.nextLine();
        String reverse = "";
        for(int i = str.length() - 1; i >= 0; i--)
        {
            reverse = reverse + str.charAt(i);
        }
        
        System.out.println("Reversed string is:");
        System.out.println(reverse);
    }
    public static void M4()
    {
         Scanner sc = new Scanner(System.in);
         String s;
         do
         {
             System.out.print("Please enter some Strings: ");
             s=sc.nextLine();
             System.out.println(s);
             if(s.equals("stop"))
             {
                 break;
             }
         }
         while (s!="stop");
    }
    public static void M5()
    {
        System.out.println("Enter seed value : ");
        Scanner sc = new Scanner(System.in);
        int seed = sc.nextInt();
        Random r= new Random(seed);
        int randomInt = 0;
        do
        {
        randomInt=r.nextInt(15) ;
	System.out.print(randomInt + " ");
        if(randomInt == 7 )
        {
            break;
        }
        }
        while(randomInt != 7 );
    }      
    public static void M6()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter first value : ");
        int start = sc.nextInt();
        System.out.println("Enter second valueshould be gretaer than first value : ");
        int end = sc.nextInt();
        int sum=0;
        for (int i=start; i<=end; i++)
        {          
           sum=sum+i;   
        }
        System.out.println("Sum is : " + sum);    
    }
    public static void M7()
    {
         Scanner sc = new Scanner(System.in);
         String s;
         System.out.print("Please enter some Strings: ");
         s=sc.nextLine();
         char[] ch = s.toCharArray();
         for(int i=0; i<s.length(); i++)
         {
             for(int j=i; j<s.length(); j++)
             {
                 System.out.print(ch[j]);
             }
             System.out.println();
         }
             
    }
    public static void M8()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter first String : ");
        String s1=sc.nextLine();
        int start = s1.length();
        System.out.println("Enter second String : ");
        String s2=sc.nextLine();
        int end = s2.length();
        for (int i=start; i<=50-end; i++)
        {          
           s1 = s1 + "X"; 
        }
        String s = s1+s2;
        System.out.println("result : " + s);    
    }
}
