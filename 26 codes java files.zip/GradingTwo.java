
package gradingtwo;
import java.util.Scanner;


public class GradingTwo {


    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        double maGrade =0.0;
        double miGrade=0.0;
        double otGrade =0.0;
        int maCourse=0;
        int miCourse=0;
        int otCourse=0;
        int n=0;
        String course;
        while(true)
        {
            System.out.println("Enter Grade  betwwen 0-100( negative value to stop ) ");
            n= sc.nextInt();
            if(n>=0 && n<=100)
            {
                System.out.println("Enter Course ");
                course= sc.next();
                
                if ( course.equals("Ma") || course.equals("ma") )
                {
                    maGrade = maGrade + (0.7*n);
                    maCourse++;
                    
                }
                else if (course.equals("Mi") || course.equals("mi") )
                {
                    miGrade = miGrade + (0.2*n);
                    miCourse++;
                    
                }
                else if ( course.equals("Ot") || course.equals("ot"))
                {
                    otGrade = otGrade + (0.1*n);
                    otCourse++;
                    
                }
                else 
                {
                    System.out.println(" Invalid Input ");
                }
            }
            else
            {
                double Average,maAverage , miAverage, otAverage =0;
                maAverage = (maGrade/maCourse);
                miAverage = (miGrade/miCourse);
                otAverage = (otGrade/otCourse);
                Average = (maAverage+miAverage+otAverage);
                System.out.println("Major Average : " + maAverage);
                System.out.println("Minor Average : " + miAverage);
                System.out.println("other Average : " + otAverage);
                System.out.println("Total Average : " + Average);
                break;
            }
        }
    }
}
