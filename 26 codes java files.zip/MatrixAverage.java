
package matrixaverage;

import java.io.File;
import java.util.Random;
import java.util.Scanner;


public class MatrixAverage {


    public static void main(String[] args) throws IOException
    {
        
             Scanner f = new Scanner(new File("MatrixAverage.txt"));
             int rows = f.nextInt();
             int columns = f.nextInt();
             int seed= f.nextInt();
             int n = rows*columns;
             double[][] matrix = new double[rows][columns];
             Input(matrix,rows,columns,seed); 
             Output(matrix,n);
    }
     public static void Input(double[][] matrix, int rows, int columns,int seed)
    {
        Random r = new Random(seed);
        for (int i =0; i<rows; i++)
        {
            for (int j =0; j<columns; j++)
            {
                matrix[i][j]=1+r.nextDouble();
            }
        }
    }
    public static void Output(double[][] matrix, int n )
    {
        //enhanced for loop
        double average,sum = 0.0;
        for (double i[] : matrix)
        {
            for (double j : i)
            {
               System.out.printf("%5.1f",j );
               System.out.print(" " );
               sum = sum + j;
            }
            System.out.println("");
        }
        average = sum/n;
        System.out.print("Average is " );
        System.out.printf("%5.1f",average);
    }

    
}
