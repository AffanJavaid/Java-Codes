
package revrsechiper;

import java.util.Scanner;

        
public class RevrseChiper {

           
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Main(sc);
    }
    public static void Main(Scanner sc)
    {

        System.out.println("Enter sentence to encrypt  : ");
        String phrase = sc.nextLine();
        System.out.println("Enter number to encrypting String : ");
        int n = sc.nextInt();
        Encrypt(phrase,n);
        sc.nextLine(); // to read next line
        System.out.println("Enter sentence to decrypt  : ");
        String phrase1 = sc.nextLine();
        System.out.println("Enter number to decrypting String : ");
        int n1 = sc.nextInt();
        Decrypt(phrase1,n1);
        
    }
    public static void Encrypt(String phrase, int n)
    {
        int j=0;
        char[] ch = phrase.toCharArray();
        char[] e = new char[phrase.length()];
        for (int i=phrase.length()-1; i>=0; i--)
        {
            e[j]= (char) (ch[i]+n);
            j++;
        }
        String Encrypted=new String(e);
        System.out.println(Encrypted);
    }
    public static void Decrypt(String phrase, int n)
    {
        int j=0;
        char[] ch = phrase.toCharArray();
        char[] e = new char[phrase.length()];
        for (int i=phrase.length()-1; i>=0; i--)
        {
            e[j]= (char) (ch[i]-n);
            j++;
        }
        String Decrypted=new String(e);
        System.out.println(Decrypted);
    }
}
