
package randomnumbers2;
import java.util.Random;
import java.util.Scanner;

public class RandomNumbers2 {

 
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter seed : ");
        int seed = sc.nextInt();
        Random r = new Random(seed);
        double[] array = new double[25];
        for(int i=0; i<25; i++) // assigning random number to list 
        {
            array[i]= r.nextDouble();
        }  
        Print(array);
    }
    public static void Print(double[] array)
    {
        double average,sum=0.0;
        for(int i=0; i<25; i++) // assigning random number to list 
        {
            System.out.printf("%.3f " + " \n ",array[i]);  //%.3f rounding off it upto 3 decimal 
            sum = sum + array[i];
        }
        average=sum/25;
        System.out.print("Average is  ");
        System.out.printf("%.3f ", average);
    }
    
}
