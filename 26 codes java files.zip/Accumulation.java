
package accumulation;
import java.util.Scanner;

public class Accumulation {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of values : ");
        int n = sc.nextInt();
        int[] array = new int[n];
        for(int i=0; i<n; i++) // assigning random number to list 
        {
            System.out.println("Write value : ");
            array[i]= sc.nextInt();
        }  
        Print(array,n);
    }
    public static void Print(int[] array, int n)
    {
        int sum=0;
        System.out.println("The array is  " );
        System.out.print("[ " );
        for(int i=0; i<n; i++) // assigning random number to list 
        {
            System.out.print( array[i] + "  ");
            sum = sum + array[i];
        }
        System.out.println("] sum is  " + sum);
    }
}
    

