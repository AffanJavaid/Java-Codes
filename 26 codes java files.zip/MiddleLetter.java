
package middleletter;

import java.io.*;
import java.util.Scanner;


public class MiddleLetter {

 
    public static void main(String[] args) throws IOException 
{
        
            Scanner f = new Scanner(new File("mid.txt"));
            String str;
            String mid;
            while (f.hasNext())
            {
                str=f.nextLine();
                mid = middle(str);
                System.out.println("middle word  " + mid );
            }
            
    }
     public static String middle(String str)
    {
        int position;
        int length;
        if (str.length() % 2 == 0)
        {
            position = str.length() / 2 - 1;
            length = 2;
        }
        else
        {
            position = str.length() / 2;
            length = 1;
        }
        return str.substring(position, position + length);
    }
}
