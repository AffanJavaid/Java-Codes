
package growingnumbers;
import java.util.Scanner;

public class GrowingNumbers {


    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number : ");
        String number = sc.nextLine();
        char[] Carr = number.toCharArray(); // converting string to char array
        int[] array = new int[Carr.length]; // converting char array to int array
        for (int i = 0; i< Carr.length; i++) 
        {
          array[i] = Character.getNumericValue(Carr[i]);
        }
        boolean check = IncreasingArray(array);
        Print(array);
        Checking(check,array);
        Sum(array);
    }
        public static boolean IncreasingArray(int[] array)
       {
        for (int i=0 ; i<array.length-1; i++ )
        {
           if (array[i]>=array[i+1])
           {
               return false;
           }
        }
        return true;
       } 
        
       public static void Checking(boolean check, int[] array)
       {
        
        if (check == true)
        {
            System.out.println("It is strongly Increasing. ");
        }
        else if (check == false)
        {
            System.out.println("It is NOT strongly Increasing. ");
        }
       }
       public static void Print(int[] array) 
       {
            System.out.print(" [ " );
            for(int i : array)
            {
                System.out.print(i + "," );
            }
            System.out.print( "] " );

       }
        public static void Sum(int[] array) 
       {
        int sum=0;
        for (int i=0 ; i<array.length; i++ )
        {
            
            sum = sum + array[i];
        }
        System.out.println("Total sum is : " + sum);
       }
}