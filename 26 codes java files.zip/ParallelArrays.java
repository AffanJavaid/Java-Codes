
package parallelarrays;

import java.io.*;

import java.util.Scanner;


public class ParallelArrays {

  
    public static void main(String[] args) throws IOException {
            Scanner f = new Scanner(new File("parallel.txt"));
            int n= f.nextInt();
            System.out.println(n); 
            String[] str= new String[n];
            int[] time = new int[n];
            for (int i=0; i<n; i++)
            {
                str[i]=f.next(); // store word
                time[i]=f.nextInt(); // store number of times repeat
            }    
        for(int j=0; j<n; j++)
        {
            for(int k =1; k<=time[j]; k++)
            {
                System.out.print(str[j] + " ");
            }
            System.out.println("");
        }
                
}
    
}
    

