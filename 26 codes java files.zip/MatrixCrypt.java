
package matrixcrypt;

import java.io.*;
import java.util.Scanner;
import java.lang.Math;
public class MatrixCrypt {


    public static void main(String[] args) throws IOException
        
    {

        Scanner f1 = new Scanner(new File("matrix.txt"));
        int lines=0;
        while(f1.hasNextLine())
        {
          lines++;
          f1.nextLine();
        }
        System.out.println(lines);
        Scanner f2 = new Scanner(new File("matrix.txt"));
        String[] str =new String[lines];
        for(int i=0; i<lines; i++)
        {
            str[i]= f2.nextLine();
        } 
        for(int i=0; i<lines; i++)
        {
            Crypt(str[i]);
        }
    }
    public static void Crypt( String str )
    {
        
        int n = str.length();
        char[] crypted = new char[n];
        double s=Math.sqrt(n);
        int rows=(int) s;
        double c=(s - rows)*10;
        int columns=0;
        if (c==0.0)// perfect square
        {
           columns = rows;    
        }
        else
        {    
           columns = (int) c;
        }
        char[][] matrix = new char[rows][columns];
        char[] ch= str.toCharArray();
  
        int k=0;
        for (int i =0; i<rows; i++)
        {
            for (int j =0; j<columns; j++)
            {
                matrix[i][j]=ch[k];
                k++;
            }
        }

       int l=0;
        for (int i =0; i<columns; i++)
        {
            for (int j =0; j<rows; j++)
            {
                crypted[l]=matrix[j][i];
                l++;
            }
        }

        String cryptStr= new String(crypted);
        System.out.println(str + " ==> " + cryptStr);

    }

}
