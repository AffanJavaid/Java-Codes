
package milesandmiles;

import java.util.Scanner;


public class MilesandMiles {


    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
         int im,fm,g=0;
         double mpg=0.0;
         do
         {
             System.out.print("initial miles : ");
             im=sc.nextInt();
             if(im<0)
             {  
                System.out.print(" Bye : ");
                break;
             }
             else
             {
             System.out.print("final miles : ");
             fm=sc.nextInt();
             System.out.print("gallons : ");
             g=sc.nextInt();
             mpg = (fm-im)/g;
             System.out.println("Miles per gallon : "+mpg);
             }
         }
         while (im>=0);
    }
    
}
