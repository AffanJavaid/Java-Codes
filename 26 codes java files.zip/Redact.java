
package redact;
import java.util.Scanner;
import java.util.*;
public class Redact {

    public static void main(String[] args) throws IOException
    {
        Scanner sc = new Scanner(new File (�Redact.txt�));
        System.out.println("Enter phrase : ");
        String phrase = sc.nextLine();
        System.out.println("Phrase is : " + phrase);
        System.out.println("Enter word to be replaced : ");
        String word = sc.next();
        System.out.println("Enter number of question marks to be added in word : ");
        int n = sc.nextInt();
        String p[] = phrase.split(" "); // make String array split after space
        for (int i =0; i<p.length; i++)
        {
            
            if ( p[i].equals(word) ) // search for word
            {
                char[] j = new char[p[i].length()+n]; // chracter array for storing ?
                for(int k=0; k<p[i].length()+n; k++)
                {
                    j[k]='?';
                }
                String Qmarks = new String(j);     // converting chracter array into string
                phrase=phrase.replaceAll(p[i], Qmarks);  // replacing word with ?
            }
        }
        System.out.println(phrase);
        
    }
}
