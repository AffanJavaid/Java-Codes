
package multiplication;
import java.io.*;
import java.util.Scanner;
public class Multiplication {


    public static void main(String[] args) throws IOException
    {
        Scanner sc = new Scanner(new File("multiplication.txt"));
        while(sc.hasNext())
        {
            int f = sc.nextInt();
            int n = sc.nextInt();
            Table(f,n);
        }
        


    }
    public static void Table(int f, int n)
    {
        int m;
        System.out.println("Table of  " + f );
        for ( int i=1; i<=n; i++)
        {
          m=f*i;  
          System.out.println(f + " x " + i + " = " + m);
        }
    }
}
