
package fizzbuzz;

import java.io.*;
import java.util.Scanner;


public class FizzBuzz {

    
    public static void main(String[] args) throws IOException
    {
        
            Scanner f = new Scanner(new File("fizz.txt"));
            int n= f.nextInt();
            int[] numbers = new int[n];
            for (int i=0; i<n; i++)
            {
                numbers[i]=f.nextInt(); // store number of times repeat
            }
            setBuzz(numbers,n);
            
        
    }
    public static void setBuzz(int[] numbers,int n)
    {
            String[] str = new String[n];
            for (int i=0; i<n; i++)
            {
               

               if(numbers[i]% 5 == 0 && numbers[i]% 3 == 0  )
               {
                   str[i]="FizzBuzz";
               }
               else if(numbers[i]%3 ==0 )
               {
                   str[i]="Fizz";
               }
               else if(numbers[i]%5 ==0 )
               {
                   str[i]="Buzz";
               }

               else
               {
                   str[i]=Integer.toString(numbers[i]);
               }
            }
            for (int i=0; i<n; i++)
            {
                System.out.println(numbers[i] + "     " + str[i]);
            }
    }
}    
