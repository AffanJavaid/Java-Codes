
package passengerlist;

import java.io.File;
import java.util.Random;
import java.util.Scanner;


public class PassengerList {

    
    public static void main(String[] args) 
    {
       
             Scanner sc = new Scanner(System.in);
             int rows = 10;
             int columns = 6;
             int i=0;
             int j=0;
             String name;
             
             String[][] matrix = new String[rows][columns];
             Input(matrix,rows,columns); 
             while (true)
             {
              System.out.println("Maximum seat row is 9 maximum seat column is 5");
              System.out.println("Enter a seat row , write -1 to quit");
              i = sc.nextInt();
              if ( i != -1)
              {
                System.out.println("Enter seat column");
                j = sc.nextInt();
                System.out.println("Name of Passanger : ");
                name  = sc.next();
                matrix[i][j] = name;
              }
              else if (i==-1)
              {
                  Output(matrix);
                  break;
              }
             }

        

    }
     public static void Input(String[][] matrix, int rows, int columns)
    {
        
        for (int i =0; i<rows; i++)
        {
            for (int j =0; j<columns; j++)
            {
                matrix[i][j]="Empty";
            }
        }
    }
    public static void Output(String[][] matrix)
    {
        for(int  i=0; i<10; i++)
        {
            for(int j=0; j<6; j++)
            {
                
                System.out.printf("%20s" , "[ " +i + "," + j +", " + matrix[i][j] + " ]");
            }
            System.out.println("");
        }
    }
   
}

