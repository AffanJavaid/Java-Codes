
package sieveeratosthenes;

import java.io.*;
import java.util.Scanner;


public class SieveEratosthenes {


    public static void main(String[] args) throws IOException {
        Scanner f = new Scanner(new File("count.txt"));
        int num=0;
        while(f.hasNext())
        {
            num=f.nextInt();
            checkPrime(num);
        }
}
    public static void checkPrime(int num)
    {
             
        String[] prime = new String[num];
        prime[1]="P";
        for (int i = 2; i<num; i++) 
          {    
             prime[i] = "P"; 
          }
        
        for (int i = 2; i<num; i++) 
          {
            if (prime[i].equals("P"))
            {
            for (int j = 2; j<num; j++) 
              {
                if(j%i==0 && j!=i)
                {
                    prime[j] = "NP";
                }   
              }
            }
          }
        System.out.println(" Prime Between  1 and " + num );
        int counter=0;
        for (int i= 1; i<num; i++) 
          {
            if(prime[i].equals("P"))
            {  
                counter++;
                System.out.print(i+"  " );
            }  
          }
        System.out.println("  " );
        System.out.println("total numbers are  "+ counter );
        }
   
    
}