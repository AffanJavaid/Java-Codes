
package shuffle;
import java.util.Random;
import java.util.Scanner;
public class Shuffle {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter seed : ");
        int seed = sc.nextInt();
        Random r = new Random(seed);
        int[] integer = new int[52];
        for(int i=0; i<51; i++) // assigning random number to list 
        {
            integer[i]= 1+r.nextInt(51);
        }
        System.out.println(" Before swapping: ");
        for(int i=0; i<51; i++)
        {
            System.out.print(integer[i] + " ");
        }
        //random number index swaping
        for(int i=0; i<51; i++)
        {
            integer[i]= integer[1+r.nextInt(51)];
        }
        System.out.println(" seed value : " + seed);
        System.out.println(" After swapping: ");
        for(int i=0; i<51; i++)
        {
            System.out.print(integer[i] + " ");
        }
       
    }
    
}
