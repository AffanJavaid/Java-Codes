
package matrixsearch;

import java.io.*;
import java.util.Random;
import java.util.Scanner;

public class MatrixSearch {

   
    public static void main(String[] args) throws IOException
    {
        
             Scanner f = new Scanner(new File("MatrixSearch.txt"));
             int seed = f.nextInt();
             int rows = f.nextInt();
             int columns = f.nextInt();
             int search1 = f.nextInt();
             int search2 = f.nextInt();
             int[][] matrix = new int[rows][columns];
             Input(matrix,rows,columns,seed); 
             Output(matrix);
             Search(matrix,rows,columns,search1); 
             Search(matrix,rows,columns,search2);

    }
     public static void Input(int[][] matrix, int rows, int columns,int seed)
    {
        Random r = new Random(seed);
        for (int i =0; i<rows; i++)
        {
            for (int j =0; j<columns; j++)
            {
                matrix[i][j]=1+r.nextInt(99);
            }
        }
    }
    public static void Output(int[][] matrix)
    {
        //enhanced for loop
        for (int i[] : matrix)
        {
            for (int j : i)
            {
               System.out.print(j + " ");
            }
            System.out.println("");
        }
    }
    public static void Search(int[][] matrix, int rows, int columns,int search)
    {
        int flag = 0;
        for (int i =0; i<rows; i++)
        {
            for (int j =0; j<columns; j++)
            {
                if(matrix[i][j]==search)
                {
                    System .out.println(search + " is at [" + i + " " + j + "]");
                    flag = 1;
                }
            }
        }
        if (flag == 0)
        {
            System.out.println(search + " is not in matrix : ");
        }
    }    
}


