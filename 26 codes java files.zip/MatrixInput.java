
package matrixinput;

import java.util.Scanner;


public class MatrixInput {

    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Number of rows : ");
        int rows = sc.nextInt();   
        System.out.println("Enter Number of columns : ");
        int columns = sc.nextInt();
        int[][] matrix = new int[rows][columns];        
        Input(matrix,rows,columns);
        Output(matrix);
    }
    public static void Input(int[][] matrix, int rows, int columns)
    {
        int n=1;
        for (int i =0; i<rows; i++)
        {
            for (int j =0; j<columns; j++)
            {
                matrix[i][j]=n;
                n++;
            }
        }
    }
    public static void Output(int[][] matrix)
    {
        //enhanced for loop
        for (int i[] : matrix)
        {
            for (int j : i)
            {
               System.out.print(j + " ");
            }
            System.out.println("");
        }
        
    }
   
}