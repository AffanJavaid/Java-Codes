
package wordsearch;
import java.util.Scanner;
import java.io.*;
import java.util.Arrays;
public class WordSearch {

   
    public static void main(String[] args) throws IOException
    {
        
            Scanner f = new Scanner(new File("word.txt"));
            int wordsNumber = f.nextInt();
            System.out.println(wordsNumber); // read first line 
            String[] str= new String[wordsNumber];
            int i=0;
            while (f.hasNext())
            {
                str[i]=f.next();
                i++;
            }
            Print(str,wordsNumber);
    }

    public static void Print(String[] str, int n)
    {
        Arrays.sort(str); //sorting the array
        for(int j=0; j<n; j++)
        {
            System.out.print(str[j] + " ");
        }
        
    }
}
