
package crypt;

import java.io.*;
import java.util.Scanner;

public class Crypt {


    public static void main(String[] args) throws IOException {
            Scanner f = new Scanner(new File("secret.txt"));
            String alphabets = f.next();
            String crypted = f.next();
            char[] a = alphabets.toCharArray();
            char[] c = crypted.toCharArray();
            int n= f.nextInt();
            System.out.println(n); 
            String[] str= new String[n];
            int s=0; 
            for (s=0; s<n; s++)
            {
                str[s]=f.nextLine(); 
            }    
            for (int i =0; i<str.length; i++)
            { 
                char[] ch = str[i].toCharArray();
                for(int k=0; k<str[i].length(); k++) 
                {
                    for(int j=0; j<alphabets.length(); j++)
                    {
                        if (ch[k] == a[j])
                        {
                            str[i]=str[i].replace(ch[k],c[j]); 
                        }
                    }
                    
                }
               
            } 
            for (int i=0; i<n; i++)
            {
                System.out.println(str[i]);
            } 
}
}

    

