
package sumitup;

import java.util.Scanner;


public class SumItUp {


    public static void main(String[] args) 
    {
       
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number N : ");
        int n = sc.nextInt();
        double sum=0.0;
        double c =1.0;
        for (int i =1; i<n; i++)
        {
           sum = sum + c/i;
        }
        System.out.println("Sum is " +  sum);
        
        
    }
    
}
    

